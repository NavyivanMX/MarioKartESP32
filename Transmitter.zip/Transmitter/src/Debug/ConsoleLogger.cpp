/******************************************************************************
 * Proyecto : MarioKart ESP32 RC
 * Archivo  : ConsoleLogger.cpp
 ******************************************************************************/

#include "src/Debug/ConsoleLogger.h"

#include <Arduino.h>

// #include "src/Shared/DriverCommandFormatter.h"
// #include "src/Shared/Version.h"

#include "src/Firmware/Firmware.h"
#include "src/Config/TransmitterConfig.h"
#include <Utilities/DriverCommandFormatter.h>


namespace MK
{

//=============================================================================

void ConsoleLogger::Begin()
{
    Serial.begin(115200);

    while (!Serial)
    {
        delay(10);
    }
}

//=============================================================================

void ConsoleLogger::LogBoot()
{
    Serial.println();

    Serial.println(F("========================================"));
    Serial.println(Firmware::ProjectName);
    Serial.println(Firmware::FirmwareName);

    Serial.print(F("Version : "));
    Serial.println(Firmware::VersionString);

    Serial.print(F("Release : "));
    Serial.println(Firmware::Release);

    Serial.print(F("Author  : "));
    Serial.println(Firmware::Author);

    if constexpr (BuildConfig::InputTestMode)
    {
        Serial.println(F("Input Test Mode"));
    }
    else
    {
        Serial.println(F("ESP-NOW Mode"));
}

    Serial.println(F("========================================"));
    Serial.println();
}
//=============================================================================

void ConsoleLogger::LogReady()
{
    Serial.println(F("----------------------------------------"));
    Serial.println(F("System Ready"));
    Serial.println(F("----------------------------------------"));
}

//=============================================================================

void ConsoleLogger::LogError(const char* message)
{
    Serial.print(F("[ERROR] "));
    Serial.println(message);
}

//=============================================================================

void ConsoleLogger::Log(const DriverCommand& command)
{
    //----------------------------------------------------------
    // Registrar únicamente cambios.
    //----------------------------------------------------------

    if (command == m_previousCommand)
    {
        return;
    }

    m_previousCommand = command;

    LogCommand(command);
}

//=============================================================================

void ConsoleLogger::LogCommand(const Protocol::DriverCommand& command)
{
    Serial.print(F("[INPUT] "));
    Serial.println(Protocol::DriverCommandFormatter::Format(command));
}

} // namespace MK