#ifndef MK_SHARED_H
#define MK_SHARED_H

//=============================================================================
// Configuración
//=============================================================================

#include "Config/Config.h"
#include "Config/RadioConfig.h"

//=============================================================================
// Tipos
//=============================================================================

#include "Types/Vehicle/Direction.h"
#include "Types/Vehicle/Steering.h"
#include "Types/Vehicle/Turbo.h"
#include "Types/Vehicle/DriveMode.h"
#include "Types/Types.h"

//=============================================================================
// Protocolo
//=============================================================================

#include "Protocol/Protocol.h"
#include "src/Protocol/VehicleStatus.h"
#include "src/Vehicle/VehicleProfiles/DrivingProfileId.h"

//=============================================================================
// Utilidades
//=============================================================================

#include "Utilities/Button.h"
#include "Utilities/DriverCommandFormatter.h"
#include "Utilities/EnumToString.h"
#include "Utilities/DriverCommandUtils.h"

//=============================================================================
// Información
//=============================================================================

#include "Version/Version.h"

#endif // MK_SHARED_H