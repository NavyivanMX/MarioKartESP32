/******************************************************************************
 * Proyecto : MarioKart ESP32 RC
 * Archivo  : Types.h
 *
 * Descripción:
 * Punto de entrada para todos los tipos compartidos.
 ******************************************************************************/

#ifndef MK_SHARED_TYPES_H
#define MK_SHARED_TYPES_H

#include "Types/MacAddress.h"

#include "Types/Vehicle/Direction.h"
#include "Types/Vehicle/DriveMode.h"
#include "Types/Vehicle/Steering.h"
#include "Types/Vehicle/Turbo.h"

#endif // MK_SHARED_TYPES_H