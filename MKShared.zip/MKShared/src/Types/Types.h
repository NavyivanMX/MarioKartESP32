/******************************************************************************
 * Proyecto : MarioKart ESP32 RC
 * Archivo  : Types.h
 * Autor    : Narciso Ivan Cisneros Acosta
 *
 * Descripción:
 * Define los tipos fundamentales compartidos por todo el proyecto.
 ******************************************************************************/

#ifndef MK_SHARED_TYPES_H
#define MK_SHARED_TYPES_H

#include <array>
#include <cstddef>
#include <cstdint>

namespace MK::Types
{

//=============================================================================
// Alias
//=============================================================================

/// Longitud de una dirección MAC.
inline constexpr std::size_t MacAddressLength = 6;

/// Tipo que representa una dirección MAC.
using MacAddress = std::array<std::uint8_t, MacAddressLength>;

//=============================================================================
// Tipos del vehículo
//=============================================================================

namespace Vehicle
{

//-----------------------------------------------------------------------------
// Movimiento longitudinal
//-----------------------------------------------------------------------------

enum class Direction : std::uint8_t
{
    Stop = 0,
    Forward,
    Reverse
};

//-----------------------------------------------------------------------------
// Dirección de giro
//-----------------------------------------------------------------------------

enum class Steering : std::uint8_t
{
    Straight = 0,
    Left,
    Right
};

//-----------------------------------------------------------------------------
// Estado del turbo
//-----------------------------------------------------------------------------

enum class Turbo : std::uint8_t
{
    Disabled = 0,
    Enabled
};

//-----------------------------------------------------------------------------
// Modo de conducción del vehículo
//-----------------------------------------------------------------------------
enum class DriveMode : std::uint8_t
{
    /// Llantas alineadas para conducción convencional.
    Normal = 0,

    /// Llantas giradas 90° para desplazamiento lateral (Mario Kart).
    Gravity
};

} // namespace Vehicle

} // namespace MK::Types

#endif // MK_SHARED_TYPES_H